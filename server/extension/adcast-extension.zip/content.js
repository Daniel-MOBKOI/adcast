/**
 * AdCast Recorder — Content Script v2
 *
 * Runs in Celtra frames. Converts mouse events to touch events WITHOUT
 * blocking the originals — fires both so Celtra can pick up whichever
 * it listens for. Does not use capture or stopPropagation.
 */

(function () {
  'use strict';

  // Signal to AdCast UI that extension is active
  if (window.location.hostname === 'adcast-mz16.onrender.com') {
    document.documentElement.setAttribute('data-adcast-ext', '1');
    return;
  }

  if (window.__adcastTouchEmulator) return;
  window.__adcastTouchEmulator = true;

  // Override touch detection BEFORE Celtra JS runs
  try {
    Object.defineProperty(navigator, 'maxTouchPoints', {
      get: function () { return 5; },
      configurable: true,
    });
    window.ontouchstart = null;
  } catch (e) {}

  var isDown = false;
  var touchId = 1;

  function makeTouch(e) {
    return new Touch({
      identifier: touchId,
      target: e.target,
      clientX: e.clientX,
      clientY: e.clientY,
      screenX: e.screenX,
      screenY: e.screenY,
      pageX: e.pageX,
      pageY: e.pageY,
      radiusX: 1, radiusY: 1,
      rotationAngle: 0, force: 1,
    });
  }

  function fire(type, e, touches) {
    var t = makeTouch(e);
    var te = new TouchEvent(type, {
      cancelable: true,
      bubbles: true,
      touches: touches,
      targetTouches: touches,
      changedTouches: [t],
    });
    // Dispatch on the target — do NOT prevent the original mouse event
    e.target.dispatchEvent(te);
  }

  // Bubble phase, passive — don't interfere with Celtra's own handlers
  document.addEventListener('mousedown', function (e) {
    if (e.button !== 0) return;
    isDown = true;
    touchId = Date.now();
    fire('touchstart', e, [makeTouch(e)]);
  });

  document.addEventListener('mousemove', function (e) {
    if (!isDown) return;
    fire('touchmove', e, [makeTouch(e)]);
  });

  document.addEventListener('mouseup', function (e) {
    if (!isDown) return;
    isDown = false;
    fire('touchend', e, []);
  });

  document.addEventListener('mouseleave', function (e) {
    if (!isDown) return;
    isDown = false;
    fire('touchcancel', e, []);
  });

  console.log('[AdCast] Touch emulator v2 active');
})();
