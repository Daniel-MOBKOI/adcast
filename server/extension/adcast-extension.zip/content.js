/**
 * AdCast Recorder — Content Script
 *
 * Runs in all frames on AdCast and Celtra pages.
 * On Celtra frames: injects touch emulation so desktop mouse events
 * are converted to touch events, enabling swipe interactions.
 * On AdCast pages: sets a flag so the UI can detect the extension.
 */

(function () {
  'use strict';

  // ── Signal to AdCast that the extension is active ──────────────────────────
  // AdCast's login page checks for this attribute on <html>
  if (window.location.hostname === 'adcast-mz16.onrender.com') {
    document.documentElement.setAttribute('data-adcast-ext', '1');
    // Also set it after any navigation
    window.addEventListener('load', () => {
      document.documentElement.setAttribute('data-adcast-ext', '1');
    });
    return; // Don't inject touch emulator on the AdCast app itself
  }

  // ── Touch emulator (runs in Celtra frames) ─────────────────────────────────
  if (window.__adcastTouchEmulator) return;
  window.__adcastTouchEmulator = true;

  // Override touch capability detection — must run before Celtra's JS
  try {
    Object.defineProperty(navigator, 'maxTouchPoints', {
      get: function () { return 5; },
      configurable: true,
    });
  } catch (e) {}

  // Add ontouchstart to window so Celtra's feature detection passes
  if (!('ontouchstart' in window)) {
    window.ontouchstart = null;
  }

  var isDown = false;
  var startX = 0, startY = 0;
  var lastX = 0, lastY = 0;
  var touchId = 0;

  function makeTouch(e, id) {
    return new Touch({
      identifier: id,
      target: e.target,
      clientX: e.clientX,
      clientY: e.clientY,
      screenX: e.screenX,
      screenY: e.screenY,
      pageX: e.pageX,
      pageY: e.pageY,
      radiusX: 1,
      radiusY: 1,
      rotationAngle: 0,
      force: 1,
    });
  }

  function fireTouchEvent(type, e, activeTouches) {
    var touch = makeTouch(e, touchId);
    var event = new TouchEvent(type, {
      cancelable: true,
      bubbles: true,
      touches: activeTouches,
      targetTouches: activeTouches,
      changedTouches: [touch],
    });
    e.preventDefault();
    e.stopImmediatePropagation();
    e.target.dispatchEvent(event);
  }

  document.addEventListener('mousedown', function (e) {
    if (e.button !== 0) return;
    isDown = true;
    touchId = Date.now();
    startX = lastX = e.clientX;
    startY = lastY = e.clientY;
    fireTouchEvent('touchstart', e, [makeTouch(e, touchId)]);
  }, { capture: true, passive: false });

  document.addEventListener('mousemove', function (e) {
    if (!isDown) return;
    var dx = Math.abs(e.clientX - lastX);
    var dy = Math.abs(e.clientY - lastY);
    if (dx < 0.5 && dy < 0.5) return;
    lastX = e.clientX;
    lastY = e.clientY;
    fireTouchEvent('touchmove', e, [makeTouch(e, touchId)]);
  }, { capture: true, passive: false });

  document.addEventListener('mouseup', function (e) {
    if (!isDown) return;
    isDown = false;
    fireTouchEvent('touchend', e, []);
  }, { capture: true, passive: false });

  document.addEventListener('mouseleave', function (e) {
    if (!isDown) return;
    isDown = false;
    fireTouchEvent('touchcancel', e, []);
  }, { capture: true, passive: false });

})();
